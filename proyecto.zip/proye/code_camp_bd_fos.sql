-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-11-2023 a las 07:20:41
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `code_camp_bd_fos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(11) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'ccbd', '0d89ec971a7bcfe26d68c177a9d53334', 'admin@gmail.com', '', '2023-02-22 07:18:13'),
(2, 'edwin', 'edwinjesus', 'edwinramirez11e17@gmail.com', 'edwin', '2023-11-29 18:28:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(11) NOT NULL,
  `rs_id` int(11) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `img` varchar(5000) NOT NULL,
  `img_principal` varchar(400) NOT NULL,
  `descuento` int(11) NOT NULL,
  `duracion` int(11) NOT NULL,
  `detalles_img` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `dishes`
--

INSERT INTO `dishes` (`d_id`, `rs_id`, `title`, `slogan`, `price`, `img`, `img_principal`, `descuento`, `duracion`, `detalles_img`) VALUES
(1, 1, 'Combo Nuggets\n', '10 Nuggets + 1 papa pequeña + 1 gaseosa pet 400ml + 1 salsa bbq + 1 salsa miel mostaza', '20900', 'https://image.jimcdn.com/app/cms/image/transf/none/path/s64310fdbd43c1c8e/image/i18eb2c5be437385f/version/1574790356/image.png', '	https://images.rappi.com/restaurants_background/mcdonaldscol-1659733638484-1695419028417.jpg?e=webp&q=40&d=300x300						', 3, 11, 'https://images.rappi.com/products/tmp467376644139319802600686867.png?d=300x300&e=webp&q=10'),
(2, 1, 'Parte Y Comparte Nuggets\n', '10 Nuggets + 10 alitas (las alitas picantes hot wings equivalen a un trozo de ala) + 2 papas pequeñas', '42900', 'https://images.rappi.com/restaurants_background/900370381_1684430738236.jpeg?e=webp&q=40&d=300x300', 'https://images.rappi.com/restaurants_background/900370381_1684430738236.jpeg?e=webp&q=40&d=300x300', 11, 15, 'https://images.rappi.com/products/tmp467376962811959969054202669.png?d=300x300&e=webp&q=10'),
(3, 1, 'Combo Infantil Nuggets\n', '5 Nuggets + 1 papa pequeña + 1 gaseosa pet 400ml + 1 salsa bbq', '15900', 'https://images.rappi.com/restaurants_background/kfc1-1657753564446.jpg', 'https://images.rappi.com/restaurants_background/mcdonaldscol-1659733638484-1695419028417.jpg?e=webp&q=40&d=300x300', 16, 23, 'https://images.rappi.com/products/tmp467376803908594156520575948.png?d=300x300&e=webp&q=10'),
(4, 1, 'Chicken Nights Para 2\n', '4 Presas de pollo + 2 sandwich bbq + 2 papas pequeñas\n', '8', 'https://i.ytimg.com/vi/BiHJKSBkB_o/maxresdefault.jpg', '0', 0, 0, 'https://images.rappi.com/products/tmp392802477055909080653498327.png?d=300x300&e=webp&q=10'),
(5, 2, 'Mccombo Doble Hamburg', 'Lleva una doble hamburguesa con queso, unas papas medianas y una bebida mediana (16oz) a elección.\n', '21', 'https://assets.dameunbite.com/images/businesses/5ec0394fedc217000411471d/product/11combomonchidoblecarne550x400png1641904218690.png', '0', 0, 0, ''),
(6, 2, 'Mccombo Doble Hamburguesa Con Queso Mediano\n', 'Deliciously Cheesy Mashed Potato. The ultimate mash for your Thanksgiving table or the perfect accompaniment to vegan sausage casserole. Everyone will love it\'s fluffy, cheesy.', '5', 'https://images.rappi.com/products/tmp466056634591059491124106606.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(7, 2, 'Crispy Chicken Strips', 'Fried chicken strips, served with special honey mustard sauce.', '8', 'https://images.rappi.com/products/tmp467380409680008118978020039.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(8, 2, 'Lemon Grilled Chicken And Pasta', 'Marinated rosemary grilled chicken breast served with mashed potatoes and your choice of pasta.', '11', 'https://images.rappi.com/products/tmp478435907117835758243828250.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(9, 3, 'Vegetable Fried Rice', 'Chinese rice wok with cabbage, beans, carrots, and spring onions.', '5', 'https://images.rappi.com/products/tmp420019939199281873292391845.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(10, 3, 'Prawn Crackers', '12 pieces deep-fried prawn crackers', '7', 'https://images.rappi.com/products/tmp4673805618310799824154865827.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(11, 3, 'Spring Rolls', 'Lightly seasoned shredded cabbage, onion and carrots, wrapped in house made spring roll wrappers, deep fried to golden brown.', '6', 'https://images.rappi.com/products/tmp4784349815716942210816525537.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(12, 3, 'Manchurian Chicken', 'Chicken pieces slow cooked with spring onions in our house made manchurian style sauce.', '11', 'https://images.rappi.com/products/tmp478434513043085186824764224.png?d=300x300&e=webp&q=10', '0', 0, 0, ''),
(13, 4, ' Buffalo Wings', 'Fried chicken wings tossed in spicy Buffalo sauce served with crisp celery sticks and Blue cheese dip.', '11', '606d765f69a19.jpg', '0', 0, 0, ''),
(14, 4, 'Mac N Cheese Bites', 'Served with our traditional spicy queso and marinara sauce.', '9', '606d768a1b2a1.jpg', '0', 0, 0, ''),
(15, 4, 'Signature Potato Twisters', 'Spiral sliced potatoes, topped with our traditional spicy queso, Monterey Jack cheese, pico de gallo, sour cream and fresh cilantro.', '6', '606d76ad0c0cb.jpg', '0', 0, 0, ''),
(16, 4, 'Meatballs Penne Pasta', 'Garlic-herb beef meatballs tossed in our house-made marinara sauce and penne pasta topped with fresh parsley.', '10', '606d76eedbb99.jpg', '0', 0, 0, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` varchar(6000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `duracion` int(11) NOT NULL,
  `img_rest` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `restaurant`
--

INSERT INTO `restaurant` (`rs_id`, `c_id`, `title`, `email`, `phone`, `url`, `o_hr`, `c_hr`, `o_days`, `address`, `image`, `date`, `duracion`, `img_rest`) VALUES
(1, 1, 'KFC - Pollo ', 'nthavern@mail.com', '3547854700', 'www.northstreettavern.com', '8am', '8pm', 'mon-sat', 'Diagonal Santander Calle 10  11 Sector Quinta Vélez. Local 116 Norte de Santander, Colombia\nHamburguesa - McDonald\'s', 'https://images.rappi.com/restaurants_logo/kfc-logo1-1568829630230-1637772320526.png?e=webp&d=10x10&q=10', '2023-11-28 23:21:49', 30, 'https://images.rappi.com/restaurants_background/kfc1-1657753564446.jpg?e=webp&q=70&d=300x300'),
(2, 2, 'McDonald\'s', 'eataly@gmail.com', '0557426406', 'www.eataly.com', '11am', '9pm', 'Mon-Sat', '800 Boylston St, Boston', 'https://images.rappi.com/restaurants_logo/l-1695429331538.png?e=webp&d=10x10&q=10', '2023-11-28 21:11:04', 14, 'https://images.rappi.com/restaurants_background/mcdonaldscol-1659733638484-1695419028417.jpg?e=webp&q=40&d=300x300'),
(3, 3, 'Doña Carmen Sabores Caceros', 'nanxiangbao45@mail.com', '1458745855', 'www.nanxiangbao45.com', '9am', '8pm', 'mon-sat', 'Queens, New York', 'https://images.rappi.com/restaurants_logo/0aa5b96c-986e-4781-aec1-9c30377b5d3f-1697668951110.png?e=webp&d=10x10&q=10', '2023-11-28 21:40:43', 17, 'https://images.rappi.com/restaurants_background/961f26a5-43b4-422c-8be5-e7738c2abf69-1697668969277.png?e=webp&q=70&d=300x300'),
(4, 4, 'Tobby Comidas Rapidas', 'hbg@mail.com', '6545687458', 'www.hbg.com', '7am', '8pm', 'mon-sat', '812 Walter Street', 'https://images.rappi.com/restaurants_logo/kfc-logo1-1568829630230-1668430778631.png?e=webp&d=100x100&q=80', '2023-11-28 21:40:38', 25, 'https://images.rappi.com/restaurants_background/900343237-1680105028199.jpg?e=webp&q=70&d=300x300');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `res_category`
--

INSERT INTO `res_category` (`c_id`, `c_name`, `date`) VALUES
(1, 'Pollo frito', '2023-11-28 04:22:29'),
(2, 'Hamburguesas', '2023-11-28 04:22:48'),
(3, 'Corriente', '2023-11-28 04:23:05'),
(4, 'Comidas Rapidas', '2023-11-28 04:23:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rol` int(12) NOT NULL,
  `dirreccion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `status`, `date`, `rol`, `dirreccion`) VALUES
(1, 'edwin', 'edwin', 'ramirez', 'edwinramirez11e17@gmail.com', '23213123', 'edwinjesus', 'ddd', 1, '2023-11-30 01:09:22', 0, 'AV 0 B # 21 B - 55'),
(9, 'edwj ', 'edw', 'edwin', 'edwinramirez11e1@gmail.com', '3028355234', '$2y$10$uUR4mj2cNcIZ4zjUcuVo4enfXJeZhobkU9oQR6Qw4mmd9C8NAZR1W', '', 1, '2023-11-30 01:09:31', 2, 'AV 0 B # 21 B - 55'),
(10, 'ramirez', 'edwinjesus', 'edwin', 'edwinramirezaaaa11e17@gmail.com', '3028355234', '$2y$10$3xcSEixu93.ncrmsLX7q3OaQ4qLtQjQ/7ZWqcvf5DENL6hCjDlNg2', '', 1, '2023-11-30 01:09:44', 0, 'AV 0 B # 21 B - 55'),
(11, '', '', '', '', '', '$2y$10$YbtxdQZoNxXuPhMG1oqgCew8pO5wf/qW0RfwITlTHU6i8Eg8E6Ya.', '', 1, '2023-11-30 05:19:27', 0, ''),
(12, 'yug', 'jhkj', 'jkkhkj', 'edwin_ramirez11@gmail.com', '(302) 8355234', '$2y$10$5C5DEsebpzFD5Iy5pd7GCuGu3BlN.P7.rqLlYchQXzoypBfbyJ/Oe', '', 1, '2023-11-30 06:16:20', 0, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` int(3) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `users_orders`
--

INSERT INTO `users_orders` (`o_id`, `u_id`, `title`, `quantity`, `price`, `status`, `date`) VALUES
(23, 3, 'Combo Nuggets\n', 1, '20900.00', 1, '2023-11-30 03:20:28'),
(27, 10, 'Combo Nuggets\n', 1, '20900.00', 1, '2023-11-30 05:15:04'),
(28, 10, 'Parte Y Comparte Nuggets\n', 1, '42900.00', 1, '2023-11-30 05:15:07'),
(29, 1, 'Combo Nuggets\n', 1, '20900.00', 0, '2023-11-30 04:35:55');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indices de la tabla `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`),
  ADD KEY `rs_id` (`rs_id`);

--
-- Indices de la tabla `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indices de la tabla `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indices de la tabla `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `dishes`
--
ALTER TABLE `dishes`
  ADD CONSTRAINT `dishes_ibfk_1` FOREIGN KEY (`rs_id`) REFERENCES `restaurant` (`rs_id`);

--
-- Filtros para la tabla `restaurant`
--
ALTER TABLE `restaurant`
  ADD CONSTRAINT `restaurant_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `res_category` (`c_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
